# Greta Van 10bis
A Chrome & Firefox extension that automatically opts-out from ordering Plastic cutlery on 10bis.co.il.

## What's with the name?
Greta Thunberg is a Swedish environmental activist on climate change whose campaigning has gained international recognition. 

That, along with the fact that Greta Van Fleet is an awesome band heavily influenced by Led Zeppelin which you should definitely check out if you're a rock fan - should give you an idea about why I chose this peculiar name. :)

<br>

<p align="center">
  <img src="./no-hadap.png">
</p>
